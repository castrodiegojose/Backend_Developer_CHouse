var numero1 = prompt("Ingrese el primer numero: ");
numero1 = parseInt(numero1);


var numero2 = prompt("Ingrese el segundo numero: ");
numero2 = parseInt(numero2);

var suma = numero1 + numero2;

alert ("La suma de "+numero1+" + "+numero2+" = "+ suma)

