

let ipComparar = prompt("Ingrese la IP que quiere comparar o ESC para Salir: ");

while (ipComparar !="ESC"){

    let validacion = isIP(ipComparar);

    if(validacion == "Valid IP"){    
        
        comparadora(ipComparar);
            
    }

    else{ 
        
        alert("Ingrese bien los Datos")
    }

ipComparar = prompt("Ingrese la IP que quiere comparar o ESC para Salir: ");
      
}   

alert("Nos Vemos!");


function isIP(ip){
    var arrIp = ip.split(".");
    console.log(arrIp);
    if (arrIp.length !== 4) return "Invalid IP";
    for (let oct of arrIp) {
        if ( isNaN(oct) || Number(oct) < 0 || Number(oct) > 255)
            return "Invalid IP";
    }
    return "Valid IP";

}




function comparadora (ipComparar){

    let ipAComparar = "10.192.168.0";
    ipAComparar = ipAComparar.split(".");
    ipComparar = ipComparar.split(".");

    

    if (ipAComparar[1] == ipComparar[1] && ipAComparar[2] == ipComparar[2] && ipAComparar[3] == ipComparar[3] && ipAComparar[4] == ipComparar[4]){

        alert("Su IP esta duplicada!");
    }
    else{
        
        alert("Su IP puede ser utilizada");
    
    }

}   