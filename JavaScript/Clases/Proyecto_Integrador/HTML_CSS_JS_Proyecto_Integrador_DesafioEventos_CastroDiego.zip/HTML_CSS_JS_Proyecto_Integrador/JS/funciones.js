// function obtenerDatos(){

//     // let eliminarElemento = document.getElementById("mensaje");
//     // console.log(eliminarElemento);
//     // eliminarElemento.removeChild("li")   ;
    
//     let ipComparar = document.getElementById("ipAComparar").value;
//     console.log(ipComparar);
    
//     let validacion = isIP(ipComparar); //Llamo a la funcion para chequear que se trata realmente de una IP
//     console.log(validacion);
//     if(validacion == "Valid IP"){    
        
//         /**Se valida q es una IP ingresada y la compara con las existentes en la funcion
     
//         comparadora la cual devuelve si esta duplicada o no como string**/
        
        
//         let alerta = comparadora(ipComparar); 
//         let eliminarElemento = document.getElementById("mensaje");   //Genero un cartel verde en HTML con DOM
//         let hijo = eliminarElemento.lastChild;
//         eliminarElemento.removeChild(hijo);

//         if (alerta === "¡¡Su IP puede ser Utilizada!!"){
//             let nuevoElemento = document.getElementById("mensaje");  
//             nuevoElemento.style.color='green';            
//             let li = document.createElement("li");                              
//             li.innerHTML = alerta;            
//             nuevoElemento.appendChild(li);
//         }
//         else{            
//             let nuevoElemento = document.getElementById("mensaje"); //Genero un cartel rojo en HTML con DOM
//             nuevoElemento.style.color='#ff0000';
//             let li = document.createElement("li");      
//             li.innerHTML = alerta;
//             nuevoElemento.appendChild(li);

//         }

        
            
//     }

//     else{ 
        
//         alert("Ingrese bien los Datos")
//     }
// }


// function borrarAlertas(){

//     let eliminarElemento = document.getElementById("mensaje");
//     let hijo = eliminarElemento.lastChild;
//     eliminarElemento.removeChild(hijo);
// }


////////////////////






////Esta Función valida que realmente sea una IP lo que se ingresa/////////

function isIP(ip){
    var arrIp = ip.split("."); //genera un array donde los elementos se separan por los puntos
    //console.log(arrIp);
    if (arrIp.length !== 4){ // si el tamaño del array no es 4 (cantidad de octetos) no es valido
     return "Invalid IP";
     }
    for (let oct of arrIp) {
        if ( isNaN(oct) || Number(oct) < 0 || Number(oct) > 255) /*chequeo q los elementos del array ademas de que sean 4 
                                                                     no sean un string y que sea un numero entre 0 y 255(rangos del octeto)*/
            return "Invalid IP";
    }
    return "Valid IP";
}



/////////// Comparo la IP ingresada con cada una de los elementos del arreglo //////////

function comparadora (ipComparar){
    console.log(ipComparar)
    for(let i of arreglo){
        console.log(i.ipInterface);
        if(i.ipInterface === ipComparar){            
            return "Su IP esta duplicada con la interfaz: "+i.descripcion+" BDI: "+i.bdi ;
        }
    }

    return "¡¡Su IP puede ser Utilizada!!";

}
    
    



 
    // ipComparar = ipComparar.split(".");
      
    /*En el siguiente "for" itero la caracteristica ipInterface de cada arreglo, la divido por los "." y
    las comparo octeto a octeto con la ingresada*/
    // for(const i of arreglo){
    //     let ipAComparar = i.ipInterface;
    //     ipAComparar = ipAComparar.split(".");

    //     if (ipAComparar[1] == ipComparar[1] && ipAComparar[2] == ipComparar[2] && ipAComparar[3] == ipComparar[3] && ipAComparar[4] == ipComparar[4]){

    //         console.log(i.descripcion);

    //         return "Su IP esta duplicada con la interfaz: "+i.descripcion+" BDI: "+i.bdi ;

    //     }

    // }

    
    // return "¡¡Su IP puede ser Utilizada!!";
  
