//IP previamentes cargadas "usadas"

class RouterInterfaces {

    constructor(bdi,descripcion,ipInterface,mascara){
        this.bdi = bdi;
        this.descripcion = descripcion;
        this.ipInterface = ipInterface;
        this.mascara = mascara;
        this.estado = "en uso";
    }

    getEstadoDeIP(){ 

        return this.estado;
    }
}

const interface1 = new RouterInterfaces("100","##Full_IP_CF219_CP##","10.187.5.9","255.255.255.248");
const interface2 = new RouterInterfaces("101","##Full_IP_CF219_OAM##","10.106.33.30","255.255.255.248");
const interface3 = new RouterInterfaces("102","##Full_IP_CF219_Datos##","10.147.69.9","255.255.255.248");

let arreglo = new Array();

arreglo.push(interface1);
arreglo.push(interface2);
arreglo.push(interface3);



/*Eventos de clicks para procesar la IP 
ingresada y para borrar las alarmas mostradas en HTML

Tambien genero el evento de la tecla Enter*/


document.getElementById("botonIngreso").addEventListener("click",obtenerDatos,false);
document.getElementById("cleaner").addEventListener("click",borrarAlertas,false);
document.getElementById("ipAComparar").addEventListener("keydown",(e)=>{
    if(e.key =='Enter'){
        e.preventDefault();
        obtenerDatos();
    }
},false);





function obtenerDatos(){

        
    let ipComparar = document.getElementById("ipAComparar").value; //Tomo con DOM lo ingresado en el formulario
      
    let validacion = isIP(ipComparar); //Llamo a la funcion para chequear que se trata realmente de una IP
    if(validacion == "Valid IP"){    
        
        /**Se valida q es una IP ingresada y la compara con las existentes en la funcion     
        comparadora la cual devuelve si esta duplicada o no como string**/      
        
        let alerta = comparadora(ipComparar);
        
        

        //// Chequeo si el elemento mensaje contiene un hijo y de ser así lo borro//////    
        let nuevoElemento = document.getElementById("mensaje");   
        console.log(nuevoElemento.lastChild);
        if(nuevoElemento.lastChild !="" && nuevoElemento.lastChild != null){
               let hijo = nuevoElemento.lastChild;
               nuevoElemento.removeChild(hijo);
        }

        //// Genero los alertas en HTML

        if (alerta === "¡¡Su IP puede ser Utilizada!!"){
            
            nuevoElemento.style.color='green'; //Genero un cartel verde en HTML con DOM           
            let li = document.createElement("li");                              
            li.innerHTML = alerta;            
            nuevoElemento.appendChild(li);
        }
        else{            
             
            nuevoElemento.style.color='#ff0000'; //Genero un cartel rojo en HTML con DOM
            let li = document.createElement("li");      
            li.innerHTML = alerta;
            nuevoElemento.appendChild(li);

        }

        
            
    }

    else{ 
        
        alert("Ingrese bien los Datos")
    }
}

function borrarAlertas(){

    let eliminarElemento = document.getElementById("mensaje");
    let hijo = eliminarElemento.lastChild;
    eliminarElemento.removeChild(hijo);
}





/////////////////////////////////////////////////////

