$(document).ready(function(){

/*Eventos de clicks con jQuery para procesar la IP 
ingresada y para borrar las alarmas mostradas en HTML

Tambien genero el evento de la tecla Enter*/

$("#botonIngreso").click(function(){obtenerDatos()});


$("#cleaner").click(function(){
    $("#mensaje").empty();
});

$("#ipAComparar").keypress(function(e){
    if(e.key =='Enter'){
                e.preventDefault();
                obtenerDatos();
            }
})


function obtenerDatos(){

        
    let ipComparar = $("#ipAComparar").val(); //Tomo con JQUERY lo ingresado en el formulario
      
    let validacion = isIP(ipComparar); //Llamo a la funcion para chequear que se trata realmente de una IP
    if(validacion == "Valid IP"){    
        
        /**Se valida q es una IP ingresada y la compara con las existentes en la funcion     
        comparadora la cual devuelve si esta duplicada o no como string**/      
        
        let alerta = comparadora(ipComparar);
        
        

        //// Chequeo si el elemento mensaje contiene un hijo y de ser así lo borro//////    
        
        ////  JQUERY
        let nuevoElemento = $("#mensaje");
        console.log(nuevoElemento)
        if(nuevoElemento){
            $("#mensaje").empty();
        }


        ////////      DOM
        
        // let nuevoElemento = document.getElementById("mensaje");   
        // console.log(nuevoElemento.lastChild);
        // if(nuevoElemento.lastChild !="" && nuevoElemento.lastChild != null){
        //        let hijo = nuevoElemento.lastChild;
        //        nuevoElemento.removeChild(hijo);
        // }

        //// Genero los alertas en HTML

        //if (alerta === "¡¡Su IP puede ser Utilizada!!"){
        if(alerta == "¡¡Su IP puede ser Utilizada!!") {
            
        /////// JQUERY

            $("#mensaje").prepend('<p id="p1">'+alerta+'</p>');            
            $("#p1").css("color", "white")
                   
            let newbutton = document.createElement("button")
            newbutton.id ="newbutton"
            newbutton.type = "button";
            newbutton.innerText="¿Deseas Gardarla?"
            $("#mensaje").append(newbutton).click(function(){
                $("#mensaje").empty();
                storagelocal()
            });

           
           
           
           ////////////      DOM
            // nuevoElemento.style.color='green'; //Genero un cartel verde en HTML con DOM           
            // let li = document.createElement("li");                              
            // li.innerHTML = alerta;            
            // nuevoElemento.appendChild(li);
            
            /*Genero un boton por si el usuario quiere guardar la IP ingresada
            para que quede guardada en el localStorage*/

            ///// aca debe ir el formulario con toda la info a agregar de la nueva interface/////
            // let newbutton = document.createElement("button")
            // newbutton.id ="newbutton"
            // newbutton.type = "button";
            // newbutton.innerText="¿Deseas Gardarla?"
            // nuevoElemento.appendChild(newbutton)
            // document.getElementById("newbutton").addEventListener("click",storagelocal(ipComparar)); //Si la guarda, llama a la funcion q guarda
            
        }
        else{            
             
            $("#mensaje").prepend('<p id="p2">'+alerta+'</p>');
            
            $("#p2").css("color", "white")
                    .fadeIn();   

            /////////////      DOM

            // nuevoElemento.style.color='#ff0000'; //Genero un cartel rojo en HTML con DOM
            // let li = document.createElement("li");      
            // li.innerHTML = alerta;
            // nuevoElemento.appendChild(li);

        }

        
            
    }

    else{ 
        
        alert("Ingrese bien los Datos")
    }
}


})


/////////////////////////////////////////////////////

