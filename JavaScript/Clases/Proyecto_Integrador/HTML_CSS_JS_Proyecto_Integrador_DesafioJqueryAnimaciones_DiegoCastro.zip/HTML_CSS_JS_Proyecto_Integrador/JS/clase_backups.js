//IP previamentes cargadas "usadas"

class RouterInterfaces {

    constructor(bdi,descripcion,ipInterface,mascara){
        this.bdi = bdi;
        this.descripcion = descripcion;
        this.ipInterface = ipInterface;
        this.mascara = mascara;
        this.estado = "en uso";
    }

    getEstadoDeIP(){ 

        return this.estado;
    }
}

const interface1 = new RouterInterfaces("100","##Full_IP_CF219_CP##","10.187.5.9","255.255.255.248");
const interface2 = new RouterInterfaces("101","##Full_IP_CF219_OAM##","10.106.33.30","255.255.255.248");
const interface3 = new RouterInterfaces("102","##Full_IP_CF219_Datos##","10.147.69.9","255.255.255.248");

let arreglo = new Array();

arreglo.push(interface1);
arreglo.push(interface2);
arreglo.push(interface3);

//// Ingreso arreglo al localstorage ///
localStorage.setItem("interfaces", JSON.stringify(arreglo));


//// Expresiones Regulares ////////

const expresiones = {
    bdi: /[0-9]{3,4}/

        
}