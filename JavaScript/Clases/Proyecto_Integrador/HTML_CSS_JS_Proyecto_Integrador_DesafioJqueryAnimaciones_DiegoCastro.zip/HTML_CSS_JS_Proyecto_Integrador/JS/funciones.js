////Esta Función valida que realmente sea una IP lo que se ingresa/////////

function isIP(ip){
    var arrIp = ip.split("."); //genera un array donde los elementos se separan por los puntos
    //console.log(arrIp);
    if (arrIp.length !== 4){ // si el tamaño del array no es 4 (cantidad de octetos) no es valido
     return "Invalid IP";
     }
    for (let oct of arrIp) {
        if ( isNaN(oct) || Number(oct) < 0 || Number(oct) > 255) /*chequeo q los elementos del array ademas de que sean 4 
                                                                     no sean un string y que sea un numero entre 0 y 255(rangos del octeto)*/
            return "Invalid IP";
    }
    return "Valid IP";
}



/////////// Comparo la IP ingresada con cada una de los elementos del arreglo //////////

function comparadora (ipComparar){
    
    console.log(ipComparar)

    let newarreglo = JSON.parse(localStorage.getItem("interfaces")) // Compara con las IP cargadas en el localstorage tambien 
    
    for(let i of newarreglo){
        console.log(i.ipInterface);
        if(i.ipInterface === ipComparar){            
            return "Su IP esta duplicada con la interfaz: "+i.descripcion+" BDI: "+i.bdi ;
        }
    }

    return "¡¡Su IP puede ser Utilizada!!";

}



//// recupero el objeto del localstorage y le pusheo la nueva interfaz (IP) ///

function storagelocal(){
    $("#formulario").fadeIn();
    $("#botonCancelar").click(function(){        
        $("#formulario").fadeOut("slow");
    })

    $("#botonAceptar").click(function(){
        let inputs = $()
    })




    // const interfaceN = new RouterInterfaces("na","Interfaz_Nueva",ipComparar,"na");
    // let newarreglo = JSON.parse(localStorage.getItem("interfaces"))   
    // newarreglo.push(interfaceN)
    // localStorage.setItem("interfaces", JSON.stringify(newarreglo))
    // //console.log(interfaceN);

}
    
    



 
    // ipComparar = ipComparar.split(".");
      
    /*En el siguiente "for" itero la caracteristica ipInterface de cada arreglo, la divido por los "." y
    las comparo octeto a octeto con la ingresada*/
    // for(const i of arreglo){
    //     let ipAComparar = i.ipInterface;
    //     ipAComparar = ipAComparar.split(".");

    //     if (ipAComparar[1] == ipComparar[1] && ipAComparar[2] == ipComparar[2] && ipAComparar[3] == ipComparar[3] && ipAComparar[4] == ipComparar[4]){

    //         console.log(i.descripcion);

    //         return "Su IP esta duplicada con la interfaz: "+i.descripcion+" BDI: "+i.bdi ;

    //     }

    // }

    
    // return "¡¡Su IP puede ser Utilizada!!";
  
