//Routers_IP

class Routers_IP{
    constructor(ipRouters){
        this.ipRouters = ipRouters;
    }

}



//Interfaces de los Routers

class RouterInterfaces {

    constructor(bdi,descripcion,ipInterface,mascara){
        this.bdi = bdi;
        this.descripcion = descripcion;
        this.ipInterface = ipInterface;
        this.mascara = mascara;
        this.estado = "en uso";
    }

    getEstadoDeIP(){ 

        return this.estado;
    }
}


//// Ingreso arreglo al localstorage ///
localStorage.setItem("interfaces", JSON.stringify(arreglo));


//// Expresiones Regulares ////////

const expresiones = {
    bdi: /[0-9]{3,4}/

        
}



