
/* Direccion del documento JSON y creo el Array donde va a ir
 la respuesta*/
const dir_backUpCisco = "JSON//BackUp_redCisco.json"
let backUpCisco = new Array();


$(document).ready(function(){


    ///// Traigo el Back UP del Router /////



    $.ajax({
        method: "GET",
        url: dir_backUpCisco,
        dataType:'json',

        success: function(respuesta){

            backUpCisco.push(respuesta);
            
        }

    });

})





////Esta Función valida que realmente sea una IP lo que se ingresa/////////

function isIP(ip){
    var arrIp = ip.split("."); //genera un array donde los elementos se separan por los puntos
    //console.log(arrIp);
    if (arrIp.length !== 4){ // si el tamaño del array no es 4 (cantidad de octetos) no es valido
     return "Invalid IP";
     }
    for (let oct of arrIp) {
        if ( isNaN(oct) || Number(oct) < 0 || Number(oct) > 255) /*chequeo q los elementos del array ademas de que sean 4 
                                                                     no sean un string y que sea un numero entre 0 y 255(rangos del octeto)*/
            return "Invalid IP";
    }
    return "Valid IP";
}



/////////// Comparo la IP ingresada con cada una de los elementos del arreglo //////////

function comparadora (ipComparar){
    
    for(const [c,v] of Object.entries(backUpCisco)){
        
        let ipRouters = v;
        for (const [id,ip] of Object.entries(ipRouters)){
            
            let Router = ip

            for(const[i,int] of Object.entries(Router) ){
                let interfaces = Object.values(int)
                let IP_Router = i
                console.log(i);
                for(const[j,val] of Object.entries(interfaces)){
                    //console.log(val.IP_Interface)
                    if(val.IP_Interface === ipComparar){            
                        return `Su IP esta duplicada con la interfaz: ${val.Description} BDI: ${val.BDI} en el Router: ${IP_Router}`;
                    }
                    
                }

                
            }
    
        }

    
    }

    return "¡¡Su IP puede ser Utilizada!!";
}



//// recupero el objeto del localstorage y le pusheo la nueva interfaz (IP) ///

function storagelocal(){
    $("#formulario").fadeIn();
    $("#botonCancelar").click(function(){        
        $("#formulario").fadeOut("slow");
    })

    $("#botonAceptar").click(function(){
        let inputs = $()
    })




    // const interfaceN = new RouterInterfaces("na","Interfaz_Nueva",ipComparar,"na");
    // let newarreglo = JSON.parse(localStorage.getItem("interfaces"))   
    // newarreglo.push(interfaceN)
    // localStorage.setItem("interfaces", JSON.stringify(newarreglo))
    // //console.log(interfaceN);

}
    
    



 
    // ipComparar = ipComparar.split(".");
      
    /*En el siguiente "for" itero la caracteristica ipInterface de cada arreglo, la divido por los "." y
    las comparo octeto a octeto con la ingresada*/
    // for(const i of arreglo){
    //     let ipAComparar = i.ipInterface;
    //     ipAComparar = ipAComparar.split(".");

    //     if (ipAComparar[1] == ipComparar[1] && ipAComparar[2] == ipComparar[2] && ipAComparar[3] == ipComparar[3] && ipAComparar[4] == ipComparar[4]){

    //         console.log(i.descripcion);

    //         return "Su IP esta duplicada con la interfaz: "+i.descripcion+" BDI: "+i.bdi ;

    //     }

    // }

    
    // return "¡¡Su IP puede ser Utilizada!!";

