//IP previamentes cargadas "usadas"

class RouterInterfaces {

    constructor(bdi,descripcion,ipInterface,mascara){
        this.bdi = bdi;
        this.descripcion = descripcion;
        this.ipInterface = ipInterface;
        this.mascara = mascara;
        this.estado = "en uso";
    }

    getEstadoDeIP(){

        return this.estado;
    }
}

const interface1 = new RouterInterfaces("100","##Full_IP_CF219_CP##","10.187.5.9","255.255.255.248");
const interface2 = new RouterInterfaces("101","##Full_IP_CF219_OAM##","10.106.33.30","255.255.255.248");
const interface3 = new RouterInterfaces("102","##Full_IP_CF219_Datos##","10.147.69.9","255.255.255.248");

let arreglo = new Array();

arreglo.push(interface1);
arreglo.push(interface2);
arreglo.push(interface3);




//Ingresar IP a comparar en el prompt
let ipComparar = prompt("Ingrese la IP que quiere comparar o ESC para Salir: ");


//Ciclo para preguntar nuevamente la IP o salir

while (ipComparar !="ESC"){

    
    let validacion = isIP(ipComparar); //Llamo a la funcion para chequear que se trata realmente de una IP

    if(validacion == "Valid IP"){    
        
       alert(comparadora(ipComparar)); /**Se valida q es una IP ingresada y la compara con las existentes en la funcion
                                        comparadora la cual devuelve si esta duplicada o no como string**/

            
    }

    else{ 
        
        alert("Ingrese bien los Datos")
    }

ipComparar = prompt("Ingrese la IP que quiere comparar o ESC para Salir: ");
      
}   

alert("Nos Vemos!");

//Esta Función valida que lo q se ingresa sea una IP
function isIP(ip){
    var arrIp = ip.split("."); //genera un array donde los elementos se separan por los puntos
    //console.log(arrIp);
    if (arrIp.length !== 4) return "Invalid IP"; // si el tamaño del array no es 4 (cantidad de octetos) no es valido
    for (let oct of arrIp) {
        if ( isNaN(oct) || Number(oct) < 0 || Number(oct) > 255) /*chequeo q los elementos del array ademas de que sean 4 
                                                                     no sean un string y que sea un numero entre 0 y 255(rangos del octeto)*/
            return "Invalid IP";
    }
    return "Valid IP";

}




function comparadora (ipComparar){

 
    ipComparar = ipComparar.split(".");
    

    // let buscarIp = arreglo.find(ipInterface => arreglo.ipInterface == ipComparar )//BUSCAR COMO HACER CON ESTE METODO!!
    // console.log(buscarIp);
    // if (buscarIp == ipComparar){
    //     return "Su IP esta duplicada!";
    // }
    // else{return "¡¡Su IP puede ser Utilizada!!";}

    
    /*En el siguiente "for" itero la caracteristica ipInterface de cada arreglo, la divido por los "." y
    las comparo octeto a octeto con la ingresada*/
    for(const i of arreglo){
        let ipAComparar = i.ipInterface;
        ipAComparar = ipAComparar.split(".");

        if (ipAComparar[1] == ipComparar[1] && ipAComparar[2] == ipComparar[2] && ipAComparar[3] == ipComparar[3] && ipAComparar[4] == ipComparar[4]){

            return "Su IP esta duplicada!";

        }

    }

    return "¡¡Su IP puede ser Utilizada!!";
  

}

  

